package de.webshop.karte.pokemon.main;

import java.io.File;
import java.io.IOException;

public class ResourceFileErstellen {
    public static void main(String[] args) {


        File resource =new File("resources");
        resource.mkdir();
        File bilder=new File("resources/PokemonBilder");
        bilder.mkdir();
        String datei="pokemonStyle.css";
        try{
            File style=new File("resources/"+datei);
            if(style.createNewFile()){
                System.out.println("Datei "+style.getName()+" wurde erstellt");
            }else{
                System.out.println("Datei existiert bereits");
            }
        }catch (IOException exception){
            exception.printStackTrace();
        }
    }
}
