package de.webshop.karte.pokemon.backend;

import de.webshop.karte.pokemon.pojos.Pokemonkarte;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * <pre>
 *     drei:
 * Beispieldaten werden erstellt.
 * Die Implementierung kann genutzt werden, um die Middletier zu testen.
 *
 * </pre>
 */
public class PokemonDaoImplDemo implements PokemonDao{

    private List<Pokemonkarte> pokemonkarteList= new ArrayList<>();
    private String[] kartenNamen={"Charizard","Lucario","Pikachu"};
    private String[] kartenFarben={"gold","silber","normalfarbe"};
    private double[] kartenPreise={0.99,0.89,0.79};


    public PokemonDaoImplDemo(int anzahl) {
       Random wuerfel=new Random();
        for (int i = 0; i < anzahl; i++) {
            String kartename= kartenNamen[wuerfel.nextInt(kartenNamen.length)];
            String karteFarbe =kartenFarben[wuerfel.nextInt(kartenFarben.length)];
            double kartePreis=kartenPreise[wuerfel.nextInt(kartenPreise.length)];

            boolean starkKarte= wuerfel.nextBoolean();
            boolean entwickeltKarte= wuerfel.nextBoolean();

//            Pokemonkarte neuErstellt=new Pokemonkarte(kartename,karteFarbe,starkKarte,entwickeltKarte,kartePreis);
//            pokemonkarteList.add(neuErstellt);

        }
    }

    @Override
    public List<Pokemonkarte> getAllPokemonkarten() {
        return pokemonkarteList;
    }

    @Override
    public void addPokemon(Pokemonkarte pokemonkarte) {

    }

    @Override
    public void deletePokemon(Pokemonkarte pokemonkarte) {

    }

    @Override
    public void updatePokemon(Pokemonkarte pokemonkarte) {

    }

}
