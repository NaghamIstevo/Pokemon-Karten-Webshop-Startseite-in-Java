package de.webshop.karte.pokemon.backend;

import de.webshop.karte.pokemon.pojos.Pokemonkarte;

import java.util.List;

/**
 * zwei:
 * Setzt das DAO-Design Pattern(Data Access Objekt englisch für Datenzugriffsobjekt) um.
 * Implementierende Klasse speichern Objekte, Lesen Objekte, löschen Objekte
 * und verändern Objekte
 */
public interface PokemonDao {
    /**
     * Holt alle karten aus der Datenhaltung ab
     *
     * @return alle Objekte aus der Datenhaltung
     */
    List<Pokemonkarte> getAllPokemonkarten();

    /**
     * Fügt der Datenhaltung eine Karte Objekt zu
     *
     * @param pokemonkarte das bisher nicht gespeicherte Pokemonkarte Objekt
     */
    void addPokemon(Pokemonkarte pokemonkarte);

    /**
     * Entfernt ein Pokemonkarte Objekt aus der Datenhaltung
     *
     * @param pokemonkarte das zu entfernende Objekt
     */
    void deletePokemon(Pokemonkarte pokemonkarte);

    /**
     * Wird in diesem Projekt nur für Preis gebraucht, weil alle andere Attribute final sind
     *
     * @param pokemonkarte wird nicht verwendet
     */
    void updatePokemon(Pokemonkarte pokemonkarte);


}
