package de.webshop.karte.pokemon.backend;

import de.webshop.karte.pokemon.pojos.Pokemonkarte;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 *  Vorlage für Objekte, die lesend und schreiben auf die Datenbank zugreifen.
 * Exceptions ausgelöst werden.
 * </pre>
 */
public class PokemonDatenbankZugriff {

    private String url = "jdbc:mysql://localhost:3306/karten_db?createDatabaseIfNotExist=true";
    private String user = "root";
    private String passwort = "";

    public void inDBspeichern(Pokemonkarte pokemonkarte){
        String sqlEingabe="INSERT INTO Pokemonkarte VALUES(NULL,?,?,?,?,?,?);";

        try (Connection verbindung=DriverManager.getConnection(url,user,passwort);
            PreparedStatement transformator=verbindung.prepareStatement(sqlEingabe,Statement.RETURN_GENERATED_KEYS)){

            transformator.setString(1,pokemonkarte.getName());
            transformator.setString(2,pokemonkarte.getKarteFarbe());
            transformator.setBoolean(3,pokemonkarte.isStarkKarte());
            transformator.setBoolean(4,pokemonkarte.isEntwickelt());
            transformator.setDouble(5,pokemonkarte.getPreis());
            transformator.setString(6,pokemonkarte.getBildDateiPfad());

            transformator.execute();
            try(ResultSet anwortMitSchluessel=transformator.getGeneratedKeys()){
               anwortMitSchluessel.next();
               int pokemonId=anwortMitSchluessel.getInt(1);
               pokemonkarte.setPokemonId(pokemonId);
            }catch(SQLException exception){
                exception.printStackTrace();
            }

        }catch (SQLException exception){
            exception.printStackTrace();
        }
    }
    /**
     * Lesen aus der Datenbank
     * Verwendet: try-with-resources: Ressourcen werden automatisch geschlossen, egal ob
     * eine Exception ausgelöst wird, oder nicht.
     */

    public List<Pokemonkarte> ausDBlesen(){
        List<Pokemonkarte> allePokemonKarten =new ArrayList<>();
        String sqlAnfrage="SELECT * FROM Pokemonkarte ";

        try(Connection verbindung= DriverManager.getConnection(url,user,passwort);
            Statement transformator= verbindung.createStatement();
            ResultSet antwort= transformator.executeQuery(sqlAnfrage)){

            while (antwort.next()){
                int schluessel=antwort.getInt("pokemonId");
                String name= antwort.getString("name");
                String karteFarbe= antwort.getString("karteFarbe");
                boolean starkkarte= antwort.getBoolean("starkKarte");
                boolean entwickelt= antwort.getBoolean("entwickelt");
                double preis=antwort.getDouble("preis");
                String bildDateiPfad=antwort.getString("bilder");

                Pokemonkarte ausDatenbank=new Pokemonkarte(name,karteFarbe,starkkarte,entwickelt,preis,bildDateiPfad);
                ausDatenbank.setPokemonId(schluessel);
                allePokemonKarten.add(ausDatenbank);
            }
        }catch (SQLException exception){
            exception.printStackTrace();
        }
        return allePokemonKarten;
   }

}
