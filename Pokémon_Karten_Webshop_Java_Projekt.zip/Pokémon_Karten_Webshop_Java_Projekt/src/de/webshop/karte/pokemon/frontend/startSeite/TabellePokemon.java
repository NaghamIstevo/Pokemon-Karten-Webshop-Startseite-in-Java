package de.webshop.karte.pokemon.frontend.startSeite;

import de.webshop.karte.pokemon.backend.PokemonDatenbankZugriff;
import de.webshop.karte.pokemon.pojos.Pokemonkarte;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import java.util.ArrayList;
import java.util.List;


/**
 * Hier wird die Tabelle einbauen und die Daten hinzufügen
 */
public class TabellePokemon {
    private TableView<PokemonKarteView> table = new TableView<>();

    public TabellePokemon() {
        // Spalte für Name
        TableColumn<PokemonKarteView, String> namecol = new TableColumn<>("Pokemon Name");
        namecol.setCellValueFactory(new PropertyValueFactory<>("name"));
        // Spalte für Farbe
        TableColumn<PokemonKarteView, String> farbeCol = new TableColumn<>("Pkemon Farbe");
        farbeCol.setCellValueFactory(new PropertyValueFactory<>("farbe"));
        // Spalte für starke Karte
        TableColumn<PokemonKarteView, Boolean> starkeKarteCol = new TableColumn<>("starkKarte");
        starkeKarteCol.setCellValueFactory(new PropertyValueFactory<>("staerke"));
        // Spalte für entwickelt
        TableColumn<PokemonKarteView, Boolean> entwickeltCol = new TableColumn<>("entwickelt");
        entwickeltCol.setCellValueFactory(new PropertyValueFactory<>("entwickelt"));
        // Spalte für preis
        TableColumn<PokemonKarteView, Double> preisCol = new TableColumn<>("Preis");
        preisCol.setCellValueFactory(new PropertyValueFactory<>("preis"));
        // Spalte für Image
        TableColumn<PokemonKarteView, ImageView> imageCol = new TableColumn<>("Images");
        imageCol.setCellValueFactory(new PropertyValueFactory<>("imageView"));
        // Spalte für Warenkorb
        TableColumn<PokemonKarteView, ImageView> warenkorbCol = new TableColumn<>("Warenkorb");
        warenkorbCol.setCellValueFactory(new PropertyValueFactory<>("warenkorb"));
        // Pkemon karte aus DB auslesen
        PokemonDatenbankZugriff dataVonDB = new PokemonDatenbankZugriff();
        List<Pokemonkarte> pokemonListe = dataVonDB.ausDBlesen();
        List<PokemonKarteView> viewList = new ArrayList<>();
        for (Pokemonkarte pokemonkarte : pokemonListe) {
            viewList.add(new PokemonKarteView(pokemonkarte));
        }
        /**
         * Hier wird die Tabelle in dynamische Liste gespeicht, um z.B.Filter durchzuführen
         */
        ObservableList<PokemonKarteView> dynamischeTabelle = FXCollections.observableList(viewList);

        table.setItems(dynamischeTabelle);
        table.getColumns().addAll(namecol, farbeCol, starkeKarteCol, entwickeltCol, preisCol, imageCol, warenkorbCol);

    }

    public TableView<PokemonKarteView> getTable() {
        return table;
    }

    /**
     * Diese Methode wird Filter Tabelle einbauen
     * @param anfang
     * @return ObservableList<PokemonKarteView>
     */

    public ObservableList<PokemonKarteView> filterTable(String anfang) {

        PokemonDatenbankZugriff dataVonDB = new PokemonDatenbankZugriff();
        List<Pokemonkarte> pokemonListe = dataVonDB.ausDBlesen();
        List<PokemonKarteView> viewList = new ArrayList<>();
        for (Pokemonkarte pokemonkarte : pokemonListe) {
            if (pokemonkarte.getName().toLowerCase().startsWith(anfang)){
                viewList.add(new PokemonKarteView(pokemonkarte));
            }
        }
        ObservableList<PokemonKarteView> dynamischeTabelle = FXCollections.observableList(viewList);
        return dynamischeTabelle;
    }
}
