package de.webshop.karte.pokemon.frontend.startSeite;


import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 File → Project Structure → Libraries → + → Java → JAR auswählen → OK
 * --module-path "C:\Users\49176\IdeaProjects\Bibliotheken\javafx-sdk-21.0.7\lib" --add-modules javafx.controls
 *
 * @author Nagham Istevo
 */
public class StartSeite extends Application {

    private TabellePokemon tabelleInstializieren = new TabellePokemon();
    private TableView<PokemonKarteView> tabelle = tabelleInstializieren.getTable();


    @Override
    public void start(Stage primaryStage) {


        primaryStage.setTitle("Pokemon webshop");

        VBox body = new VBox();
        //++++++++++++ Hier wird Header logo + Warenkorb einbauen+++++++++++
        BorderPane headerKomponent = new BorderPane();
        Image logo = new Image("file:resources/logo/logoMaximusWebshop.png");
        ImageView logoView = new ImageView(logo);
        logoView.setFitWidth(90);
        logoView.setFitHeight(40);
        //logoView.setPreserveRatio(true);
        headerKomponent.setLeft(logoView);

        Image warenkorbPfad = new Image("file:resources/bilder/warenkorb.png");
        ImageView warenkorb = new ImageView(warenkorbPfad);
        warenkorb.setFitWidth(40);
        warenkorb.setFitHeight(40);
        headerKomponent.setRight(warenkorb);

        //+++++++++++++Hier wird Begruessung+ input feld einbauen+++++++++++++++++++
        GridPane root = new GridPane(600, 400);
        root.setAlignment(Pos.CENTER);
        root.setGridLinesVisible(false);

        root.setHgap(5);
        root.setVgap(5);

        Label begruessung = new Label("Willkommen bei PokemonWebshop");
        root.add(begruessung, 0, 1, 7, 1);
        // erstellen eingabefeld
        Label inputfeldLabel = new Label("Bitte geben Sie Hier der Name der Pokemonkarte ein!");
        root.add(inputfeldLabel, 2, 2, 7, 1);
        TextField inputfeld = new TextField();
        inputfeld.setPromptText("Pokemon Name");
        root.add(inputfeld, 2, 3, 3, 1);
        // Erstelle den Search-Button
        Button search = new Button("Suchen");
        root.add(search, 5, 3);

        //+++++++++++++++++Hier wird Table anzeigen++++++++++++++++
        GridPane tabellePos = new GridPane();
        tabelle.setPrefWidth(630);
        tabelle.setPrefHeight(600);
        tabellePos.add(tabelle, 0, 0);
        tabellePos.setAlignment(Pos.CENTER);

        //++++++++++Beim Klick auf den search Button wird fillter tabelle angezeigt+++++++++

        search.setOnAction(e -> {
            String input = inputfeld.getText().toLowerCase();
            ObservableList<PokemonKarteView> filterList = new TabellePokemon().filterTable(input);
            tabelle.setItems(filterList);
        });
        //+++++++++++++++++++++Ende Filter Tabelle+++++++++++

        body.getChildren().addAll(headerKomponent, root, tabellePos);
        Scene scene = new Scene(body, 700, 900);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
