package de.webshop.karte.pokemon.frontend.startSeite;

import de.webshop.karte.pokemon.pojos.Pokemonkarte;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Hier wird die Eigenschaften name,farbe,staerke,entwickelt,preis,imageView,warenkorb erstellt,
 * die die spalte Name entsprechnd, um die Tabelle in javafx einzubauen
 */
public class PokemonKarteView {

    private final SimpleStringProperty name;
    private final SimpleStringProperty farbe;
    private final SimpleBooleanProperty staerke;
    private final SimpleBooleanProperty entwickelt;
    private final SimpleDoubleProperty preis;
    private final ImageView imageView;
    private final ImageView warenkorb;

    public PokemonKarteView(Pokemonkarte pokemonkarte) {
        this.name = new SimpleStringProperty(pokemonkarte.getName());
        this.farbe = new SimpleStringProperty(pokemonkarte.getKarteFarbe());
        this.staerke = new SimpleBooleanProperty(pokemonkarte.isStarkKarte());
        this.entwickelt = new SimpleBooleanProperty(pokemonkarte.isEntwickelt());
        this.preis = new SimpleDoubleProperty(pokemonkarte.getPreis());

        Image image = new Image("file:" + pokemonkarte.getBildDateiPfad());
        this.imageView = new ImageView(image);
        this.imageView.setFitWidth(70);
        this.imageView.setFitHeight(70);

        Image warenkorbBild= new Image("file:resources/bilder/warenkorb.png");
        this.warenkorb = new ImageView(warenkorbBild);
        this.warenkorb.setFitWidth(35);
        this.warenkorb.setFitHeight(40);
    }


    public String getName() {
        return name.get();
    }

    public String getFarbe() {
        return farbe.get();
    }

    public boolean isStaerke() {
        return staerke.get();
    }

    public boolean isEntwickelt() {
        return entwickelt.get();
    }

    public double getPreis() {
        return preis.get();
    }

    public ImageView getImageView() {
        return imageView;
    }

    public ImageView getWarenkorb() {
        return warenkorb;
    }
}

