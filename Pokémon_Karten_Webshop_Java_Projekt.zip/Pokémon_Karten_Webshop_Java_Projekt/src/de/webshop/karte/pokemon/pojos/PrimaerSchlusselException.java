package de.webshop.karte.pokemon.pojos;

public class PrimaerSchlusselException extends RuntimeException{
    public PrimaerSchlusselException() {
    }

    public PrimaerSchlusselException(String message) {
        super(message);
    }
}
