package de.webshop.karte.pokemon.pojos;

import javafx.scene.image.ImageView;

import java.io.Serializable;
import java.util.Objects;

/**
 * <pre>
 * eins:
 * Die Daten des Karte sollen gespeichert werden
 * POJO Klasse die der Tabelle 'Pokemonkarte' entspricht
 * Data Transfer Object: DTO
 * </pre>
 */
public class Pokemonkarte {
    /** id ist notwendig, damit die Objekt mit Datenbanktabellen matchen können
     * Entspricht der Primärschlüssel-Spalte aus der Tabelle
     * Wird von der Datenbank vergeben, sonst 0*/
    private int pokemonId;
    /** Name der Karte, zb Pikachu*/
    private final String name ;
    /** Die Frabe der Karte, zb gold, silber oder normalfarbe*/
    private final String karteFarbe;
    /** gibt an, die karte stark oder schwach*/
    private final boolean starkKarte;
    /** gibt an, ob die Pokemon entwickelt ist */
    private boolean entwickelt;
    private double preis;
    private String bildDateiPfad;

    /**
     * <pre>
     *     erstellt ein "Default", zb praktisch beim Testen
     * </pre>
     */
    public Pokemonkarte(){
        name="Pikachu";
        karteFarbe="gold";
        starkKarte=true;
        entwickelt=false;
        preis= 0.99;
    }

    /**
     * für Inizialisierung des Objekt
     */
    public Pokemonkarte(String name, String karteFarbe, boolean starkKarte, boolean entwickelt,double preis,String bildDateiPfad) {
        this.name = name;
        this.karteFarbe = karteFarbe;
        this.starkKarte = starkKarte;
        this.entwickelt = entwickelt;
        this.preis=preis;
        this.bildDateiPfad=bildDateiPfad;
    }

    public int getPokemonId() {
        return pokemonId;
    }

    /**
     * Der Name des Pokemon
     * @return name
     */
    public String getName() {return name;}

    /**
     * Die Farbe der Karte z.b silber,gold,rainbaw und normal
     * @return
     */
    public String getKarteFarbe() {return karteFarbe;}
    /**
     *  eine Karte stark oder schwach ist, oder schon entwicklt.
     */
    public boolean isStarkKarte() {return starkKarte;}
    /**
     *  eine Karte ist schon entwicklt oder nicht.
     */
    public boolean isEntwickelt() {return entwickelt;}
    /**
     *  gibt zurück preis der karte
     */
    public double getPreis() {
        return preis;
    }
    /**
     *  gibt zurück pfad für das Bild
     */
    public String getBildDateiPfad() {
        return bildDateiPfad;
    }

    /** Excpetion für id auslösen */
    public void setPokemonId(int pokemonId) {
        if(this.pokemonId !=0){
            throw new PrimaerSchlusselException();
        }
        this.pokemonId = pokemonId;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Pokemonkarte that = (Pokemonkarte) o;
        return pokemonId == that.pokemonId && starkKarte == that.starkKarte && entwickelt == that.entwickelt && Double.compare(preis, that.preis) == 0 && Objects.equals(name, that.name) && Objects.equals(karteFarbe, that.karteFarbe) && Objects.equals(bildDateiPfad, that.bildDateiPfad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pokemonId, name, karteFarbe, starkKarte, entwickelt, preis, bildDateiPfad);
    }

    @Override
    public String toString() {
        return "Pokemonkarte{" +
                "pokemonId=" + pokemonId +
                ", name='" + name + '\'' +
                ", karteFarbe='" + karteFarbe + '\'' +
                ", starkKarte=" + starkKarte +
                ", entwickelt=" + entwickelt +
                ", preis=" + preis +
                ", bildDateiPfad='" + bildDateiPfad + '\'' +
                '}';
    }
}
