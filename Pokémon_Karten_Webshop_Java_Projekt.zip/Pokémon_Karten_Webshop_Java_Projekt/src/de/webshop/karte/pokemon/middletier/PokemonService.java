package de.webshop.karte.pokemon.middletier;

import de.webshop.karte.pokemon.backend.PokemonDatenbankZugriff;
import de.webshop.karte.pokemon.pojos.Pokemonkarte;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
/**
 * <pre>
 *    Hier wird die gesamte Geschäftslogik abbilden.
 * </pre>
 */
public class PokemonService {
    private List<Pokemonkarte> listeVonAllePokemon;
    private PokemonDatenbankZugriff james;


    /**
     * Dependency Injection (DJ)
     * "Lose Koppelung" zwischen Datenbank und Service
     * @param james ein Objekt, das das PokomonDao Interface implementiert
     */

    public PokemonService(PokemonDatenbankZugriff james){
        this.james=james;
        listeVonAllePokemon=james.ausDBlesen();
    }
    /**
     * Service: stellt die alle Namen von Pokemon zur Verfügung
     */
    public Set<String> alleNamenErstellen(){
        Set<String> alleNamen= new HashSet<>();
        for (Pokemonkarte elem:listeVonAllePokemon){
            alleNamen.add(elem.getName());
        }
        return alleNamen;
    }
    /**
     * Service: stellt die alle farbe von PokemonKarte zur Verfügung
     */
    public Set<String> alleFarbeKarteErstellen(){
        Set<String> alleFarbeKarten=new HashSet<>();
        for(Pokemonkarte elem: listeVonAllePokemon){
            alleFarbeKarten.add(elem.getKarteFarbe());
        }
        return alleFarbeKarten;
    }
    /**
     * Service: stellt eine List von alle stärke Pokemon Karte zur Verfügung
     */
     public List<Pokemonkarte> alleStarkeKarteErstellen(){
        List<Pokemonkarte> alleStarkeKarten=new ArrayList<>();
        for (Pokemonkarte elem:listeVonAllePokemon){
           if(elem.isStarkKarte()){
               alleStarkeKarten.add(elem);
           }
        }
        return alleStarkeKarten;
     }
    /**
     * Service: stellt eine List von alle entwickelte Pokemon Karte zur Verfügung
     */
    public List<Pokemonkarte>alleEntwickelteKartenErstellen(){
        List<Pokemonkarte> alleEntwickelteKarten=new ArrayList<>();
        for(Pokemonkarte elem:listeVonAllePokemon){
            if(elem.isEntwickelt()){
                alleEntwickelteKarten.add(elem);
            }
        }
        return alleEntwickelteKarten;
    }
    /**
     * Service: stellt eine List von preise von Pokemon Karte zur Verfügung
     */
    public Set<Double> allePeiseErstellen(){
        Set<Double> allePreise= new HashSet<>();
        for (Pokemonkarte elem:listeVonAllePokemon){
            allePreise.add(elem.getPreis());
        }
        return allePreise;
    }

    /**
     * ein bereitstelle Methode für suchkriterium
     * @param suchkriterium
     * @return
     */
    public List<Pokemonkarte> kartenSuchen(Predicate <Pokemonkarte> suchkriterium){
        return listeVonAllePokemon.stream().filter(suchkriterium).toList();
    }












}
