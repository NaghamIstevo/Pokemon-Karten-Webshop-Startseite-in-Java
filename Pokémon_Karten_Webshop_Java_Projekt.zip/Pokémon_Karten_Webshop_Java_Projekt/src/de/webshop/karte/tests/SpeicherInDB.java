package de.webshop.karte.tests;

import java.util.ArrayList;
import java.util.List;

public class SpeicherInDB {
    public static void main(String[] args) {

        List<String> pokemonNameListe=new ArrayList<>();
        pokemonNameListe.add("Arceus-VSTAR");
    }
}
