package de.webshop.karte.tests;

import de.webshop.karte.pokemon.backend.PokemonDaoImplDemo;
import de.webshop.karte.pokemon.pojos.Pokemonkarte;

import java.util.List;

public class PokemonDaoImplDemoTest {
    public static void main(String[] args) {


        PokemonDaoImplDemo pokemon=new PokemonDaoImplDemo(7);


        List<Pokemonkarte> sieben=pokemon.getAllPokemonkarten();

        sieben.forEach(elem -> System.out.println(elem));



    }
}
