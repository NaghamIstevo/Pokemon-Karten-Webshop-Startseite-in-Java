package de.webshop.karte.tests;

import de.webshop.karte.pokemon.pojos.Pokemonkarte;

import java.sql.*;

public class LesentestvonDB {
    public static void main(String[] args) throws SQLException{

        String url = "jdbc:mysql://localhost:3306/karten_db?createDatabaseIfNotExist=true";
        String user = "root";
        String passwort = "";
        Connection verbindung = DriverManager.getConnection(url,user,passwort);
        String sqlAnfrage="SELECT * FROM Pokemonkarte ";
            Statement transformator= verbindung.createStatement();
            ResultSet antwort= transformator.executeQuery(sqlAnfrage);

            while (antwort.next()){
                int schluessel=antwort.getInt("pokemonId");
                String name= antwort.getString("name");
                String karteFarbe= antwort.getString("karteFarbe");
                boolean starkkarte= antwort.getBoolean("starkKarte");
                boolean entwickelt= antwort.getBoolean("entwickelt");
                double preis=antwort.getDouble("preis");

               // Pokemonkarte ausDatenbank=new Pokemonkarte(name,karteFarbe,starkkarte,entwickelt,preis);

//                Pokemonkarte test= new Pokemonkarte(name,karteFarbe,starkkarte,entwickelt,preis);
//                System.out.println(test);
            }



    }
}
