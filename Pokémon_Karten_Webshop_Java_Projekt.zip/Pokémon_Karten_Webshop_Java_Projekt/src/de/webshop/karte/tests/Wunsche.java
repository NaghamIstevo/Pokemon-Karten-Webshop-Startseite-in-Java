package de.webshop.karte.tests;

import de.webshop.karte.pokemon.backend.PokemonDatenbankZugriff;
import de.webshop.karte.pokemon.middletier.PokemonService;
import de.webshop.karte.pokemon.pojos.Pokemonkarte;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Wunsche {
    public static void main(String[] args) {

        PokemonDatenbankZugriff james= new PokemonDatenbankZugriff();
        PokemonService service=new PokemonService(james);

        Set<String> namen=service.alleNamenErstellen().stream().filter(name->name.toLowerCase().startsWith("d")).collect(Collectors.toSet());

        namen.forEach(name -> System.out.println(name));

        List<Pokemonkarte> dieKarten=service.kartenSuchen(karte ->karte.getName().toLowerCase().startsWith("d"));

        dieKarten.forEach(karte -> System.out.println(karte));
    }
}
