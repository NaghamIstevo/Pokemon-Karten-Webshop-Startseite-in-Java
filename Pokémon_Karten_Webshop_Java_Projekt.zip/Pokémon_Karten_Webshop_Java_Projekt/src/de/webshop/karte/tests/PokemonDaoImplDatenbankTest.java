package de.webshop.karte.tests;

import de.webshop.karte.pokemon.backend.PokemonDatenbankZugriff;
import de.webshop.karte.pokemon.pojos.Pokemonkarte;

import java.sql.SQLException;

public class PokemonDaoImplDatenbankTest {
    public static void main(String[] args) throws SQLException {
//         String url = "jdbc:mysql://localhost:3306/karten_db?createDatabaseIfNotExist=true";
//       String user = "root";
//         String passwort = "";
//        Connection verbindung = DriverManager.getConnection(url,user,passwort);
//        System.out.println(verbindung);

        PokemonDatenbankZugriff james = new PokemonDatenbankZugriff();
        Pokemonkarte raichu= new Pokemonkarte("Raichu","normal",false,false,0.99,"resources/pokemonBilder/Paichu.png");
        //james.inDBspeichern(raichu);
        james.ausDBlesen();
        System.out.println(raichu);

    }
}
